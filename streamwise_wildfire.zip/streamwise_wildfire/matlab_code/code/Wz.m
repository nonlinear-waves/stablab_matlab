function out = Wz(x,p)

out = -sign(x)*p.wx;

