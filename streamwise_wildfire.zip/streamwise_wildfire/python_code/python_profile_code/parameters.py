#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Apr  2 14:15:07 2024

@author: oliviachandrasekhar
"""

#parameters

import numpy as np

l=0.027; #heat transfer coefficient
vstar=.1 #initial fuel load
alpha=0.05

