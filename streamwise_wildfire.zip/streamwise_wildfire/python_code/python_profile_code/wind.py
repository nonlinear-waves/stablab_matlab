def wind(x,alpha):
    
    import numpy as np
    
    out = -np.sign(x)*alpha
    
    return out 


