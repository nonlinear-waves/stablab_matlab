# MATLAB-to-Python translation

This project translates the MATLAB code in `matlab.zip` for the exponential and linear density profiles.

## Install

```bash
python -m pip install -r requirements.txt
```

## Run

From this directory:

```bash
python -m exponential_profile.driver_fig1
python -m exponential_profile.driver_fig2
python -m exponential_profile.driver_fig3
python -m exponential_profile.driver_k_is_1
python -m exponential_profile.driver_mu_zero

python -m linear_profile.driver_fig1
python -m linear_profile.driver_fig2
python -m linear_profile.driver_fig3
```

The linear-profile drivers use SciPy's stiff `BDF` solver as the closest standard SciPy counterpart to MATLAB's `ode15s`. The original MATLAB `.mat` data files are retained. `driver_fig1.py` writes `rts1.mat`; `driver_fig2.py` reads it and writes `rts2.mat`, matching the original file-based workflow.

The drivers display plots. For headless environments, set `MPLBACKEND=Agg` and replace or remove `plt.show()` if image files are needed.
