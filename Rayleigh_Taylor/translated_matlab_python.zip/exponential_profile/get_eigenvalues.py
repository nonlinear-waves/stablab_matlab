"""Translation of exponential_profile/get_eigenvalues.m."""

from __future__ import annotations

import math


def get_eigenvalue(index: int, k: float, a: float, h: float) -> float:
    """Return the eigenvalue for one mode index, using MATLAB's bisection."""
    eps = 1.0e-10
    gravitational_constant = 9.8

    x1 = -math.pi / h + 2.0 * math.pi * index / h + eps
    x2 = math.pi / h + 2.0 * math.pi * index / h - eps

    def characteristic(x: float) -> float:
        return (4.0 * k**2 - a**2 + x**2) * math.tan(x * h / 2.0) + 2.0 * a * x

    g1 = characteristic(x1)
    g2 = characteristic(x2)
    if g1 * g2 >= 0.0:
        raise ValueError("root is not bracketed")

    while abs((x2 - x1) / x1) > 1.0e-12:
        xmid = (x1 + x2) / 2.0
        gmid = characteristic(xmid)
        if gmid == 0.0:
            x1 = x2 = xmid
            break
        if math.copysign(1.0, gmid) == math.copysign(1.0, g2):
            x2 = xmid
            g2 = gmid
        else:
            x1 = xmid
            g1 = gmid

    x = (x1 + x2) / 2.0
    return math.sqrt(4.0 * k**2 * a * gravitational_constant / (a**2 + 4.0 * k**2 + x**2))

