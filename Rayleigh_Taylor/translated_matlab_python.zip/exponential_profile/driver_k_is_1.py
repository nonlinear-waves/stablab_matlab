"""Compute the special k=1 root and corresponding eigenvalue."""

import math


def main() -> None:
    rho_m, rho_p, h, g = 0.1, 1.0, 1.5, 9.8
    a = math.log(rho_p / rho_m) / h
    left, right = 1.5, 5.0

    def characteristic(mu: float) -> float:
        return (4.0 - a**2 - mu**2) * math.tanh(mu * h / 2.0) + 2.0 * a * mu

    f_left = characteristic(left)
    f_right = characteristic(right)
    if f_left * f_right >= 0.0:
        raise ValueError("root not straddled")

    while right - left > 1.0e-8:
        mid = 0.5 * (left + right)
        f_mid = characteristic(mid)
        if math.copysign(1.0, f_mid) == math.copysign(1.0, f_left):
            left, f_left = mid, f_mid
        elif math.copysign(1.0, f_mid) == math.copysign(1.0, f_right):
            right, f_right = mid, f_mid
        elif f_mid == 0.0:
            break
        else:
            raise RuntimeError("problem with bisection method")

    mu = mid
    lam2 = -(2.0 * g * math.tanh(mu * h / 2.0)) / (mu - a * math.tanh(mu * h / 2.0))
    print(f"mu = {mu:.16g}")
    print(f"lam2 = {lam2:.16g}")


if __name__ == "__main__":
    main()
