"""Compute the quantities from the mu=0 calculation."""

import numpy as np
from scipy.integrate import solve_ivp


def main() -> None:
    rho_m, rho_p, h, g = 0.1, 1.0, 1.5, 9.8
    a = np.log(rho_p / rho_m) / h

    matrix = np.array([[0.0, 1.0], [-a**2 / 4.0, -a]])

    def ode(_x: float, y: np.ndarray) -> np.ndarray:
        return matrix @ y

    solution = solve_ivp(ode, (-h, 0.0), np.array([0.0, 1.0]), method="BDF", rtol=1e-10, atol=1e-10)
    temp = solution.y[:, -1]

    constant = -g * temp[1] / temp[0]
    k2 = -a * temp[1] / temp[0] - a**2 / 4.0
    term = (2.0 / h) * (2.0 * h - a**2) - 1.0 / (4.0 * h**2)
    print(f"constant = {constant:.16g}")
    print(f"k2 = {k2:.16g}")
    print(f"term = {term:.16g}")


if __name__ == "__main__":
    main()
