"""Plot the first five eigenvalues at k=200."""

import matplotlib.pyplot as plt
import numpy as np

try:
    from .get_eigenvalues import get_eigenvalue
except ImportError:  # Allows running this file from its directory.
    from get_eigenvalues import get_eigenvalue


def main() -> None:
    rho_m, rho_p, h = 0.1, 1.0, 1.5
    g = 9.8
    a = np.log(rho_p / rho_m) / h
    atwood_number = (rho_p - rho_m) / (rho_p + rho_m)
    print(f"\nAtwood number = {atwood_number:4.4g}")

    k = 200.0
    mode_indices = np.arange(1, 6)
    eigenvalues = np.array([get_eigenvalue(int(j), k, a, h) for j in mode_indices])
    bound = np.sqrt(a * g)

    plt.figure()
    plt.plot([1, 5], [bound, bound], "--b", linewidth=2)
    plt.plot(mode_indices, eigenvalues, ".-k", markersize=18, linewidth=2)
    plt.axis([1, 5, 3.86, 1.001 * eigenvalues.max()])
    plt.xlabel("Mode index j", fontsize=18)
    plt.ylabel(r"$\lambda$", fontsize=18)
    plt.tick_params(labelsize=18)
    plt.show()


if __name__ == "__main__":
    main()
