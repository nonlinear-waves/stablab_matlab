"""Plot the top eigenvalue as a function of k."""

import matplotlib.pyplot as plt
import numpy as np

try:
    from .get_eigenvalues import get_eigenvalue
except ImportError:  # Allows running this file from its directory.
    from get_eigenvalues import get_eigenvalue


def main() -> None:
    rho_m, rho_p, h, length = 0.1, 1.0, 1.5, 1.0
    g = 9.8
    a = np.log(rho_p / rho_m) / h
    atwood_number = (rho_p - rho_m) / (rho_p + rho_m)
    print(f"\nAtwood number = {atwood_number:4.4g}")

    num_k_indices = 200
    k_vals = np.arange(1, num_k_indices + 1, dtype=float) / length
    eigenvalues = np.array([get_eigenvalue(1, k, a, h) for k in k_vals])
    bound = np.sqrt(a * g)

    plt.figure()
    plt.plot(k_vals, eigenvalues, ".k", markersize=6)
    plt.plot([0, num_k_indices], [bound, bound], "--b", linewidth=1)
    mx = eigenvalues.max()
    plt.axis([-1, num_k_indices, -0.1 * mx, 1.1 * mx])
    plt.xlabel("k", fontsize=18)
    plt.ylabel(r"$\lambda$", fontsize=18)
    plt.tick_params(labelsize=18)
    plt.show()


if __name__ == "__main__":
    main()
