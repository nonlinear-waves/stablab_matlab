"""Translation of linear_profile/A.m."""

import numpy as np

try:
    from .parameters import Parameters
except ImportError:  # Allows running this file from its directory.
    from parameters import Parameters


def A(x: float, lam: float, p: Parameters) -> np.ndarray:
    """Return the 2-by-2 Evans matrix for the linear density profile."""
    rho_0 = p.rho_m + p.rho_0_der * (x + p.h)
    density_ratio_derivative = p.rho_0_der / rho_0
    return np.array(
        [
            [0.0, 1.0],
            [p.k**2 * (1.0 - p.g * density_ratio_derivative / lam**2), -density_ratio_derivative],
        ]
    )
