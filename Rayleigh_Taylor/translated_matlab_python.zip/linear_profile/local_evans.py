"""Translation of linear_profile/local_evans.m."""

import numpy as np
from scipy.integrate import solve_ivp

try:
    from .drury_no_radial_local import drury_no_radial_local
    from .parameters import Parameters
except ImportError:  # Allows running this file from its directory.
    from drury_no_radial_local import drury_no_radial_local
    from parameters import Parameters


def local_evans(lam: float, p: Parameters, rtol: float = 1.0e-10, atol: float = 1.0e-10) -> float:
    """Evaluate the Evans function using a stiff ODE solver."""
    solution = solve_ivp(
        lambda t, y: drury_no_radial_local(t, y, lam, p, n=2, k_manifold=1),
        (-p.h, 0.0),
        np.array([0.0, 1.0]),
        method="BDF",
        rtol=rtol,
        atol=atol,
    )
    if not solution.success:
        raise RuntimeError(f"Evans ODE integration failed: {solution.message}")
    temp = solution.y[:, -1]
    return p.rho_p * (lam**2 * temp[1] + p.g * p.k**2 * temp[0])
