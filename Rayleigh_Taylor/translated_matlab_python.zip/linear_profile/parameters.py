"""Parameter container corresponding to MATLAB's parameter struct ``p``."""

from dataclasses import dataclass


@dataclass
class Parameters:
    rho_m: float = 0.1
    rho_p: float = 0.2
    h: float = 2.0
    length: float = 1.0
    g: float = 9.8

    def __post_init__(self) -> None:
        self.rho_0_der = (self.rho_p - self.rho_m) / self.h
        self.L0 = 1.0 / max(self.rho_0_der / self.rho_m, self.rho_0_der / self.rho_p)
        self.Atwood_number = (self.rho_p - self.rho_m) / (self.rho_p + self.rho_m)
        self.k = 0.0
