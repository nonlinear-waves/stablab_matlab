"""Translation of linear_profile/drury_no_radial_local.m."""

import numpy as np

try:
    from .parameters import Parameters
except ImportError:  # Allows running this file from its directory.
    from parameters import Parameters


def drury_no_radial_local(
    t: float,
    y: np.ndarray,
    lam: float,
    p: Parameters,
    n: int = 2,
    k_manifold: int = 1,
) -> np.ndarray:
    """Right-hand side for continuous orthogonalization (Drury's method)."""
    W = np.reshape(y[: k_manifold * n], (n, k_manifold), order="F")
    A_temp = A(t, lam, p)
    derivative = (np.eye(n) - W @ W.T) @ A_temp @ W
    return np.reshape(derivative, n * k_manifold, order="F")


def A(x: float, lam: float, p: Parameters) -> np.ndarray:
    """Local copy of the Evans matrix to keep this module directly runnable."""
    rho_0 = p.rho_m + p.rho_0_der * (x + p.h)
    density_ratio_derivative = p.rho_0_der / rho_0
    return np.array(
        [
            [0.0, 1.0],
            [p.k**2 * (1.0 - p.g * density_ratio_derivative / lam**2), -density_ratio_derivative],
        ]
    )
