"""Translation of linear_profile/get_eigenvalues.m."""

from __future__ import annotations

import numpy as np

try:
    from .local_evans import local_evans
    from .parameters import Parameters
except ImportError:  # Allows running this file from its directory.
    from local_evans import local_evans
    from parameters import Parameters


def get_eigenvalues(
    p: Parameters,
    choices: int | list[int] | np.ndarray,
    left: float,
    right: float,
    num_nodes: int = 10,
) -> float | np.ndarray:
    """Find one or more eigenvalues by bracketing Evans-function sign changes."""
    scalar_choice = np.isscalar(choices)
    choices_array = np.atleast_1d(np.asarray(choices, dtype=int))
    bound = np.sqrt(p.g / p.L0)
    lambda_vals = np.linspace(left, min(right, bound), num_nodes)
    D = np.array([local_evans(lam, p) for lam in lambda_vals])

    sign_change_indices = np.flatnonzero(D[1:] * D[:-1] < 0.0)
    if len(sign_change_indices) == 0:
        raise ValueError("no Evans-function sign change found in the requested interval")

    out = np.zeros(choices_array.shape, dtype=float)
    for output_index, choice in enumerate(choices_array):
        if choice < 1 or choice > len(sign_change_indices):
            raise ValueError(f"choice {choice} is unavailable; found {len(sign_change_indices)} roots")
        root_index = sign_change_indices[-int(choice)]
        a = lambda_vals[root_index]
        fa = D[root_index]
        b = lambda_vals[root_index + 1]
        c = a
        while b - a > 1.0e-8:
            c = 0.5 * (a + b)
            fc = local_evans(c, p)
            if np.sign(fc) == np.sign(fa):
                a, fa = c, fc
            else:
                b = c
        out[output_index] = c

    return float(out[0]) if scalar_choice else out
