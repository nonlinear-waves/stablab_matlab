"""Plot the largest eigenvalue as a function of k."""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from scipy.io import savemat

try:
    from .get_eigenvalues import get_eigenvalues
    from .parameters import Parameters
except ImportError:  # Allows running this file from its directory.
    from get_eigenvalues import get_eigenvalues
    from parameters import Parameters


def main() -> None:
    p = Parameters()
    choices = 1
    k_max = 680
    left, right = 0.01, 2.0
    k_vals = np.arange(1, k_max + 1, dtype=float) / p.length
    rts1 = np.zeros_like(k_vals)

    for j, k in enumerate(k_vals):
        print(j + 1)
        p.k = k
        rts1[j] = get_eigenvalues(p, choices, left, right)
        left = rts1[j]
        right = 2.0 if j == 0 else 2.0 * rts1[j] - rts1[j - 1]

    savemat(Path(__file__).with_name("rts1.mat"), {"rts1": rts1.reshape(1, -1)})
    plt.figure()
    plt.plot(k_vals, rts1, ".k", markersize=6)
    bound = np.sqrt(p.g / p.L0)
    plt.plot([k_vals[0], k_vals[-1]], [bound, bound], "--b", linewidth=1)
    plt.xlabel("k", fontsize=18)
    plt.ylabel(r"$\lambda_1(k)$", fontsize=18)
    plt.tick_params(labelsize=18)
    plt.axis([-2, k_vals[-1], 0, 1.1 * rts1.max()])
    plt.show()


if __name__ == "__main__":
    main()
