"""Plot the first five eigenvalues at the largest wavenumber."""

import matplotlib.pyplot as plt
import numpy as np

try:
    from .get_eigenvalues import get_eigenvalues
    from .parameters import Parameters
except ImportError:  # Allows running this file from its directory.
    from get_eigenvalues import get_eigenvalues
    from parameters import Parameters


def main() -> None:
    p = Parameters()
    choices = np.arange(1, 6)
    k_max = 680
    p.k = k_max / p.length
    eigenvalues = get_eigenvalues(p, choices, 1.5, 2.193, num_nodes=1000)
    bound = np.sqrt(p.g / p.L0)

    plt.figure()
    plt.plot([1, 5], [bound, bound], "--b", linewidth=2)
    plt.plot(choices, eigenvalues, ".-k", markersize=18, linewidth=2)
    plt.axis([1, 5, 0, 1.1 * eigenvalues.max()])
    plt.xlabel("Mode index j", fontsize=18)
    plt.ylabel(r"$\lambda$", fontsize=18)
    plt.tick_params(labelsize=18)
    plt.show()


if __name__ == "__main__":
    main()
