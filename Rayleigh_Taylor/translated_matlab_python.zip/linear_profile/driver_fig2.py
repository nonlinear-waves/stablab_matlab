"""Plot the largest and second-largest eigenvalues as functions of k."""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from scipy.io import loadmat, savemat

try:
    from .get_eigenvalues import get_eigenvalues
    from .parameters import Parameters
except ImportError:  # Allows running this file from its directory.
    from get_eigenvalues import get_eigenvalues
    from parameters import Parameters


def main() -> None:
    profile_dir = Path(__file__).resolve().parent
    rts1 = np.asarray(loadmat(profile_dir / "rts1.mat")["rts1"]).ravel()
    p = Parameters()
    choices = 2
    k_max = 680
    left, right = 0.001, 2.0
    k_vals = np.arange(1, k_max + 1, dtype=float) / p.length
    rts2 = np.zeros_like(k_vals)

    plt.figure()
    plt.plot(k_vals, rts1, ".r", markersize=8)
    bound = np.sqrt(p.g / p.L0)
    plt.plot([k_vals[0], k_vals[-1]], [bound, bound], "--b", linewidth=2)

    for j in range(len(k_vals) - 1):
        print(j + 1)
        p.k = k_vals[j]
        rts2[j] = get_eigenvalues(p, choices, left, right)
        left = rts2[j]
        if j > 0:
            right = min(2.0 * rts2[j] - rts2[j - 1], rts1[j + 1] - 1.0e-6)
        else:
            choices = 1
            right = rts1[1] - 1.0e-6
        plt.plot(p.k, rts2[j], ".k", markersize=18)

    savemat(profile_dir / "rts2.mat", {"rts2": rts2.reshape(1, -1)})
    plt.figure()
    plt.plot(k_vals, rts2, ".k", markersize=8)
    plt.plot([k_vals[0], k_vals[-1]], [bound, bound], "--b", linewidth=2)
    plt.xlabel("k", fontsize=18)
    plt.ylabel(r"$\lambda_2(k)$", fontsize=18)
    plt.tick_params(labelsize=18)
    plt.axis([-2, k_vals[-1], 0, 1.1 * rts2.max()])
    plt.show()


if __name__ == "__main__":
    main()
